const  express = require('express');
const  jade = require('jade');
const  fs = require('fs');
const  router = express.Router();
const  bodyparser= require('body-parser')
const mysql = require('mysql')
// define the home page route
const  client = mysql.createConnection({
    host: 'localhost',        // DB서버 IP주소
    port: 3306,                // DB서버 Port주소
    user: 'root',                // DB접속 아이디
    password: '201233382',              // 비밀번호(설정X)
    database: 'final_exam'       //사용할 DB명
});

router.post('/',function(req,res){
      console.log('여기')
      console.log(req.body.username,req.body.user_email1,req.body.user_email2,req.body.userid)
      client.query("select userpw from user_infos where username=? and user_email1=? and user_email2=? and userid=? ",[req.body.username,req.body.user_email1,req.body.user_email2,req.body.userid] ,
        function(error, results){
      console.log('DB로부터 데이터를 검색!')
      console.log(results)
      try{
        res.status(200).send(results[0])
      }catch(Exception){
        res.status(600).send(results)
      }
  })
      
})


// 외부로 뺍니다.
module.exports = router