const   express = require('express')
const   app = express()
const 	login_post = require('./login_post')
const	join_post = require('./join_post')
const 	bodyparser = require('body-parser')
const 	check_userid = require('./select_id_in_join_post')
const	findid = require('./findid')
const	findpw = require('./findpw')
app.use(bodyparser.urlencoded({ extended: false }))
app.use('/login',login_post)
app.use('/join',join_post)
app.use('/check_userid',check_userid)
app.use('/findid',findid)
app.use('/findpw',findpw)
// 서버를 실행합니다.
app.listen(55736, function () {
       console.log('Server http://localhost:55736');
});