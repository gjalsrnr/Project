const  express = require('express');
const  fs = require('fs');
const  mysql = require('mysql');
const  ejs = require('ejs');
const jade = require('jade')
const bodyparser = require('body-parser')
const  router = express.Router();

const   client = mysql.createConnection({
    host: 'localhost',        // DB서버 IP주소
    port: 3306,                // DB서버 Port주소
    user: 'root',                // DB접속 아이디
    password: '201233382',              // 비밀번호(설정X)
    database: 'final_exam'       //사용할 DB명
});


router.post('/',function(req,res)
{
    console.log('아이디확인')
    console.log("id",req.body.id)
    client.query("SELECT  userid  FROM  user_infos where userid='"+req.body.id+"'", function(error, results){
        console.log("result",results)
        if(results==null){
            console.log("1")
            res.status(200).send(results)}
        else{
            console.log("2")
            res.status(200).send(results[0])
    }
  })
})

module.exports = router