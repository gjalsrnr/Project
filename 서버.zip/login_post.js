const  express = require('express');
const  fs = require('fs');
const  mysql = require('mysql');
const  ejs = require('ejs');
const jade = require('jade')
const bodyparser = require('body-parser')
const  router = express.Router();

const   client = mysql.createConnection({
    host: 'localhost',        // DB서버 IP주소
    port: 3306,                // DB서버 Port주소
    user: 'root',                // DB접속 아이디
    password: '201233382',              // 비밀번호(설정X)
    database: 'final_exam'       //사용할 DB명
});

router.post('/',function(req,res){
    console.log("접속한 아이디:",req.body.id)//id
    console.log("접속한 비밀번호:",req.body.pw)//pw
    client.query("SELECT userid FROM user_infos where userid='"+req.body.id+"' and userpw='"+req.body.pw+"'", function(error, results){
        try{
        console.log("존재 여부 : ",results[0])
        res.status(200).send(results[0])
        }catch(exception){
            console.log("존재 여부 : ",results)
            res.status(200).send(results)
        }
    })
})


// 외부로 뺍니다.
module.exports = router