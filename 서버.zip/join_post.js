// routerA.js 파일
// 모듈과 변수 선언
const  express = require('express');
const  jade = require('jade');
const  fs = require('fs');
const  router = express.Router();
const  bodyparser= require('body-parser')
const mysql = require('mysql')
// define the home page route
const  client = mysql.createConnection({
    host: 'localhost',        // DB서버 IP주소
    port: 3306,                // DB서버 Port주소
    user: 'root',                // DB접속 아이디
    password: '201233382',              // 비밀번호(설정X)
    database: 'final_exam'       //사용할 DB명
});
router.get('/', function(req, res) {

});
router.post('/',function(req,res){
      console.log('여기')
      console.log(req.body.id,req.body.pw,req.body.email1,req.body.email2,req.body.username, req.body.master)
      client.query('INSERT INTO user_infos VALUES (?,?,?,?,?,?)',
      [req.body.id,req.body.pw,req.body.email1,req.body.email2,req.body.username,req.body.master], 
      function(error, results){
      console.log('DB로부터 데이터를 입력!')
      console.log(results)
	 })
})


// 외부로 뺍니다.
module.exports = router